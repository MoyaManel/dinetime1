document.addEventListener('DOMContentLoaded', function () {
  // Busca el botón de cerrar sesión por su texto o ubicación en el menú
  // Ajusta este selector según tu estructura HTML actual
  const logoutButton = document.querySelector('.nav-menu a[data-action="logout"]');
  
  const userIcon = document.getElementById('user-icon');
  // Busca el botón de login, ajusta según tu estructura HTML
  const loginButton = document.querySelector('.nav-menu a[href="login.html"]');
  
  function checkAuth() {
      const token = localStorage.getItem('accessToken');
      const userId = localStorage.getItem('userId');
      const isLoggedIn = token && userId;
      
      // Mostrar/ocultar icono de usuario
      if (userIcon) {
          userIcon.style.display = isLoggedIn ? 'inline-block' : 'none';
      }
      
      // Mostrar/ocultar botones de login/logout según estado de sesión
      if (loginButton) {
          loginButton.style.display = isLoggedIn ? 'none' : 'inline-block';
      }
      
      if (logoutButton) {
          logoutButton.style.display = isLoggedIn ? 'inline-block' : 'none';
      }
      
      // Si el usuario no está logueado y estamos en una página que requiere autenticación
      // redirigir a index.html (opcional, depende de tu lógica de aplicación)
      if (!isLoggedIn && window.location.pathname.includes('perfil.html')) {
          window.location.href = 'index.html';
      }
  }
  
  function logout() {
      // Limpiar datos de sesión del localStorage
      localStorage.removeItem('accessToken');
      localStorage.removeItem('userId');
      localStorage.removeItem('userName');
      localStorage.removeItem('userRole');
      
      // Notificar al usuario
      alert("Sesión cerrada correctamente");
      
      // Redirigir a la página principal
      window.location.href = 'index.html';
      
      // Recargar la página para actualizar la interfaz
      setTimeout(() => {
          window.location.reload();
      }, 100);
  }
  
  // Asociar evento de logout al botón correspondiente
  if (logoutButton) {
      console.log('Botón de logout encontrado:', logoutButton);
      logoutButton.addEventListener('click', function (e) {
          console.log('Click en botón de logout');
          e.preventDefault();
          logout();
      });
  } else {
      console.error('Botón de logout no encontrado en el DOM');
  }
  
  // Verificar autenticación al cargar la página
  checkAuth();
  
  // =============================
  // Funcionalidad de secciones
  // =============================
  const navLinks = document.querySelectorAll('.nav-menu a[data-section]');
  const secciones = {
      'Mis Reservas': 'reservas-section',
      'Detalles de la Cuenta': 'cuenta-section',
      'Mis Reseñas': 'resenas-section'
  };
  
  navLinks.forEach(link => {
      link.addEventListener('click', function (e) {
          const text = this.textContent.trim();
          
          // Si es el botón de logout, no prevenir el comportamiento por defecto
          // para que pueda ejecutar la función de logout
          if (this.getAttribute('data-action') === 'logout') {
              return;
          }
          
          e.preventDefault();
          
          // Marca como activo el link
          navLinks.forEach(l => l.classList.remove('active'));
          this.classList.add('active');
          
          // Muestra la sección correspondiente
          Object.values(secciones).forEach(id => {
              const section = document.getElementById(id);
              if (section) section.style.display = 'none';
          });
          
          const targetId = secciones[text];
          if (targetId) {
              const sectionToShow = document.getElementById(targetId);
              if (sectionToShow) sectionToShow.style.display = 'block';
          }
      });
  });
});