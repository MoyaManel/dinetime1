function obtenerRestauranteDeURL() {
  const params = new URLSearchParams(window.location.search);
  const restauranteParam = params.get('restaurante'); 

  if (restauranteParam) {
    return restauranteParam.replace('.html', '');
  }

  return null;
}

function aplicarClaseRestaurante() {
  const restaurante = obtenerRestauranteDeURL();

  if (restaurante) {
    const clase = restaurante.toLowerCase();
    document.body.classList.add(clase);
    console.log(`[DineTime] Clase añadida al <body>: ${clase}`);
  } else {
    console.warn("[DineTime] No se encontró el parámetro 'restaurante' en la URL.");
  }
}

function obtenerRestauranteParaRedireccion() {
  const urlParams = new URLSearchParams(window.location.search);
  const restaurante = urlParams.get('restaurante');

  if (restaurante) {
    return restaurante.endsWith('.html') ? restaurante : `${restaurante}.html`;
  }

  const referrer = document.referrer;
  if (referrer) {
    const urlReferrer = new URL(referrer);
    const pageName = urlReferrer.pathname.split('/').pop();
    return pageName || 'index.html';
  }

  return 'index.html';
}

document.addEventListener('DOMContentLoaded', function () {
  aplicarClaseRestaurante();

  const urlParams = new URLSearchParams(window.location.search);
  const date = urlParams.get('date') || '22 abr';
  const time = urlParams.get('time') || '19:00';
  const people = urlParams.get('people') || '2';
  const restaurantPage = obtenerRestauranteParaRedireccion();

  const restaurantName = urlParams.get('restaurant_name') || 'Restaurante';
  const restaurantNameElement = document.getElementById('restaurante-name');
  if (restaurantNameElement) {
    restaurantNameElement.textContent = `${restaurantName} - Barcelona`;
  }

  const restauranteSlug = obtenerRestauranteDeURL();
  const imgEl = document.getElementById('restaurante-img');
  if (imgEl && restauranteSlug) {
    imgEl.src = `/assets/${restauranteSlug}.jpeg`;
    imgEl.alt = restaurantName;
  }

  const dateEl = document.getElementById('reservation-date');
  if (dateEl) dateEl.textContent = date;

  const timeEl = document.getElementById('reservation-time');
  if (timeEl) timeEl.textContent = time;

  const peopleEl = document.getElementById('reservation-people');
  if (peopleEl) peopleEl.textContent = `${people} personas (Asiento estándar)`;

  let minutes = 5;
  let seconds = 0;
  const countdownTimer = document.getElementById('countdown-timer');

  if (countdownTimer) {
    const countdownInterval = setInterval(() => {
      seconds--;
      if (seconds < 0) {
        minutes--;
        seconds = 59;
      }

      if (minutes < 0 || (minutes === 0 && seconds === 0)) {
        clearInterval(countdownInterval);
        countdownTimer.textContent = '0:00 minutos';
        alert('El tiempo para completar la reserva ha expirado. Serás redirigido a la página del restaurante.');
        window.location.href = restaurantPage;
      } else {
        countdownTimer.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds} minutos`;
      }
    }, 1000);

    window.countdownInterval = countdownInterval;
  }

  const confirmBtn = document.querySelector('.btn-confirm');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      if (window.countdownInterval) clearInterval(window.countdownInterval);

      const nombre = document.getElementById('user-name');
      const telefono = document.getElementById('user-phone');
      const email = document.getElementById('user-email');

      if (nombre && !nombre.value.trim()) {
        alert('Por favor, introduce tu nombre.');
        nombre.focus();
        return;
      }

      if (telefono && !telefono.value.trim()) {
        alert('Por favor, introduce tu número de teléfono.');
        telefono.focus();
        return;
      }

      if (email && !email.value.trim()) {
        alert('Por favor, introduce tu correo electrónico.');
        email.focus();
        return;
      }

      alert('¡Reserva completada con éxito!');
      window.location.href = restaurantPage;
    });
  }
});
